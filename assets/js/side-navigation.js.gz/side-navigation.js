!function(e){"function"==typeof define&&define.amd?define(e):e()}((function(){"use strict";document.addEventListener("DOMContentLoaded",(function(){console.log("Hello world from Jekyll scripts!")}))}));
//# sourceMappingURL=side-navigation.js.map
