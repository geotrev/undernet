export { default } from "./collapsible"
